(function($){
	$(document).ready(function() {	

		// Scroll to Top
		jQuery('.scrollto-top').click(function(){
			jQuery('html').animate({'scrollTop' : '0px'}, 400);
			return false;
		});
		
		jQuery(window).scroll(function(){
			var upto = jQuery(window).scrollTop();
			if(upto > 500) {
				jQuery('.scrollto-top').fadeIn();
			} else {
				jQuery('.scrollto-top').fadeOut();
			}
		});

		// headerfixed
		$(window).scroll(function() {
			var scroll = $(window).scrollTop();
			
			if (scroll >= 10) {
			$(".header-area").addClass("headerfixed");
			} else {
			$(".header-area").removeClass("headerfixed");
			}
		});


		// scrollspy
		$(".about").click(function() {
			$("html, body").animate({ scrollTop: $("#about").offset().top }, 400);
		});

		$(".research").click(function() {
			$("html, body").animate({ scrollTop: $("#research").offset().top }, 400);
		});

		$(".solution").click(function() {
			$("html, body").animate({ scrollTop: $("#solution").offset().top }, 400);
		});

		$(".partner").click(function() {
			$("html, body").animate({ scrollTop: $("#partner").offset().top }, 400);
		});

		$(".contact").click(function() {
			$("html, body").animate({ scrollTop: $("#contact").offset().top }, 400);
		});


		// research toggle item
		jQuery(".research-left a").click(function() {
			jQuery(".hide-research").toggle()
			return false;
		});



		
		
	});
})(jQuery);